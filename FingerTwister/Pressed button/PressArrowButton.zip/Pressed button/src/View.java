import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Random;


public class View extends JFrame implements KeyListener {

    public JPanel panel;
    public JButton buttonUP;
    public JButton buttonLEFT;
    public JButton buttonDOWN;
    public JButton buttonRIGHT;
    public View() {
        this.setSize(400,150);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        panel = new JPanel(new FlowLayout(FlowLayout.CENTER));

/*      Random r = new Random();
        char c = (char)(r.nextInt(26) + 'a');*/

        buttonUP = new JButton();
        buttonUP.addKeyListener(this);
        buttonLEFT = new JButton();
        buttonLEFT.addKeyListener(this);
        buttonDOWN = new JButton();
        buttonDOWN.addKeyListener(this);
        buttonRIGHT = new JButton();
        buttonRIGHT.addKeyListener(this);

        panel.add(buttonUP);
        panel.add(buttonLEFT);
        panel.add(buttonDOWN);
        panel.add(buttonRIGHT);

        panel.addKeyListener(this);
        this.add(panel);
        this.setVisible(true);
    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
        System.out.println(e.getKeyChar());


        int keyCode = e.getKeyCode();
        switch (keyCode) {
            case KeyEvent.VK_UP:
                buttonUP.setText("UP");
                buttonUP.setBackground(Color.GREEN);
                break;
            case KeyEvent.VK_DOWN:
                buttonDOWN.setText("DOWN");
                buttonDOWN.setBackground(Color.RED);
                break;
            case KeyEvent.VK_LEFT:
                buttonLEFT.setText("LEFT");
                buttonLEFT.setBackground(Color.BLUE);
                break;
            case KeyEvent.VK_RIGHT:
                buttonRIGHT.setText("RIGHT");
                buttonRIGHT.setBackground(Color.YELLOW);
                break;
            default:
                break;
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        int keyCode = e.getKeyCode();
        switch (keyCode) {
            case KeyEvent.VK_UP:
                System.out.println("Up");
                buttonUP.setText("");
                buttonUP.setBackground(null);
                break;
            case KeyEvent.VK_DOWN:
                System.out.println("Down");
                buttonDOWN.setText("");
                buttonDOWN.setBackground(null);
                break;
            case KeyEvent.VK_LEFT:
                System.out.println("Left");
                buttonLEFT.setText("");
                buttonLEFT.setBackground(null);
                break;
            case KeyEvent.VK_RIGHT:
                System.out.println("Right");
                buttonRIGHT.setText("");
                buttonRIGHT.setBackground(null);
                break;
            default:
                break;
        }
    }

    public JPanel getPanel() {
        return panel;
    }

    public void setPanel(JPanel panel) {
        this.panel = panel;
    }

    public JButton getButtonUP() {
        return buttonUP;
    }

    public void setButtonUP(JButton buttonUP) {
        this.buttonUP = buttonUP;
    }

    public JButton getButtonLEFT() {
        return buttonLEFT;
    }

    public void setButtonLEFT(JButton buttonLEFT) {
        this.buttonLEFT = buttonLEFT;
    }

    public JButton getButtonDOWN() {
        return buttonDOWN;
    }

    public void setButtonDOWN(JButton buttonDOWN) {
        this.buttonDOWN = buttonDOWN;
    }

    public JButton getButtonRIGHT() {
        return buttonRIGHT;
    }

    public void setButtonRIGHT(JButton buttonRIGHT) {
        this.buttonRIGHT = buttonRIGHT;
    }
}
